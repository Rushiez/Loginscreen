package org.valleycollege.loginscreen;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {





}